package tests_with_login;

import io.github.bonigarcia.wdm.WebDriverManager;
import methods.LoginMethods;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import pages.BasePage;
import utilities.PropertyManager;

public class BaseTestWithLogin {
    protected WebDriver driver;

    @BeforeMethod
    public void setup(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver(new ChromeOptions().addArguments("--disable-notifications")
                .addArguments("--start-maximized"));

        BasePage basePage = new BasePage(driver);
        LoginMethods loginMethods = new LoginMethods(driver);
        basePage.basePage();
        loginMethods.login(PropertyManager.getInstance().getUserName(),
                PropertyManager.getInstance().getPassword());
    }


    @AfterMethod
    public void tearDown(){
        driver.quit();
    }
}
