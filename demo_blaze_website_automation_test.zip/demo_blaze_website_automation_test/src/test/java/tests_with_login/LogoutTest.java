package tests_with_login;

import methods.LoginMethods;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.VerificationPage;

public class LogoutTest extends BaseTestWithLogin{
    @Test


    public void logout(){
        LoginMethods loginMethods = new LoginMethods(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        loginMethods.logout();
        try{verificationPage.verifyLogout("Log in");
            System.out.println("User is logout successfully");
    }catch (Exception e){
            Assert.fail("Something went wrong!");
        }
    }
}