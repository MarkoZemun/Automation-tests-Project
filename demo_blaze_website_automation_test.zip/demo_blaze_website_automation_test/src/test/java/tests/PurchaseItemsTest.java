package tests;

import methods.LoginMethods;
import methods.PurchaseMethods;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.BasePage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class PurchaseItemsTest extends BaseTest {

    @Test

    public void purchaseItemsTest()  {

        LoginMethods loginMethods = new LoginMethods(driver);
        BasePage basePage = new BasePage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        PurchaseMethods purchaseMethods = new PurchaseMethods(driver);


        basePage.basePage();
        loginMethods.login(PropertyManager.getInstance().getUserName(),
                PropertyManager.getInstance().getPassword());
        purchaseMethods.purchase(PropertyManager.getInstance().getNamePlaceOrderForm(),PropertyManager.getInstance().getCountryPlaceOrderForm(),PropertyManager.getInstance().getCityPlaceOrderForm(),PropertyManager.getInstance().getCreditCartPlaceOrderForm(),PropertyManager.getInstance().getMonthPlaceOrderForm(),PropertyManager.getInstance().getYearPlaceOrderForm());;
        loginMethods.logout();


        try {
            verificationPage.verifyLogout("Log in");
            System.out.printf("SVE JE OKEJ");
        } catch (Exception e) {
            Assert.fail("SOMETHING WENT WRONG");
        }
    }
}