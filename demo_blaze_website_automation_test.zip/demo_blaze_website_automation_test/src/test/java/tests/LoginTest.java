package tests;

import methods.LoginMethods;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.BasePage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class LoginTest extends BaseTest{

    @Test

    public void login(){


        LoginMethods loginMethods = new LoginMethods(driver);
        BasePage basePage = new BasePage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);

        basePage.basePage();
        loginMethods.login(PropertyManager.getInstance().getUserName(),
                PropertyManager.getInstance().getPassword());
        try{verificationPage.verifyLogin("Log out");
            System.out.println("User is Login successfully!");
        }catch (Exception e){
            Assert.fail("Something went wrong!");
        }





    }
}
