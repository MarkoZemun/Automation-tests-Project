package tests;

import dataCreation.DataCreation;
import methods.RegistrationMethods;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.BasePage;
import pages.VerificationPage;


public class RegistrationTest extends BaseTest{

    @Test

    public void registration() {

        RegistrationMethods registrationMethods = new RegistrationMethods(driver);
        BasePage basePage = new BasePage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        DataCreation dataCreation = new DataCreation();



        basePage.basePage();
        registrationMethods.registration(dataCreation.randomUsername(),
                dataCreation.randomPassword());


        try {
            verificationPage.verifySignUp("PRODUCT STORE");
            System.out.println("User successfully SignUp");
        } catch (Exception e) {
            Assert.fail("Something went wrong!");
        }
    }
}
