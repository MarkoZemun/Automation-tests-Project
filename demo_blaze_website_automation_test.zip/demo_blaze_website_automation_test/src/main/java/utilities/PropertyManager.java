package utilities;

import java.io.FileInputStream;
import java.util.Properties;


public class PropertyManager {

    private static String url;
    private static String userName;
    private static String password;
    private static String namePlaceOrderForm;
    private static String contryPlaceOrderForm;
    private static String cityPlaceOrderForm;
    private static String creditCartPlaceOrderForm;
    private static String monthPlaceOrderForm;
    private static String yearPlaceOrderForm;



    public static PropertyManager getInstance(){
        Properties properties = new Properties();
        PropertyManager propertyManager = new PropertyManager();

try{
    FileInputStream fi = new FileInputStream("src/main/resources/configuration.properties");
    properties.load(fi);
    }catch (Exception e){
        e.printStackTrace();
    }
    url = properties.getProperty("url");
    userName = properties.getProperty("userName");
    password = properties.getProperty("password");
    namePlaceOrderForm = properties.getProperty("namePlaceOrderForm");
    contryPlaceOrderForm = properties.getProperty("contryPlaceOrderForm");
    cityPlaceOrderForm = properties.getProperty("cityPlaceOrderForm");
    creditCartPlaceOrderForm = properties.getProperty("creditCartPlaceOrderForm");
    monthPlaceOrderForm = properties.getProperty("monthPlaceOrderForm");
    yearPlaceOrderForm = properties.getProperty("yearPlaceOrderForm");
return propertyManager;
}


    public String getUrl(){
        return url;
}
    public String getUserName(){
        return userName;
}
    public String getPassword(){
        return password;
}
    public String getNamePlaceOrderForm() {
        return namePlaceOrderForm;
    }
    public String getCountryPlaceOrderForm() {
        return contryPlaceOrderForm;
    }
    public String getCityPlaceOrderForm() {
        return cityPlaceOrderForm;
    }
    public String getCreditCartPlaceOrderForm() {
        return creditCartPlaceOrderForm;
    }
    public String getMonthPlaceOrderForm() {
        return monthPlaceOrderForm;
    }
    public String getYearPlaceOrderForm() {
        return yearPlaceOrderForm;
    }
}
