package dataCreation;


import com.github.javafaker.Faker;


public class DataCreation {


    public static String randomUsername(){
        Faker faker = new Faker();
        String fake = faker.name().firstName();
        return fake;
    }
    public static String randomPassword(){
        Faker faker = new Faker();
        String fake = faker.internet().password();
        return fake;
    }




}
