package pages;

import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage{
    public LoginPage(WebDriver driver) {
        super(driver);
    }
    By loginButtonBeforeLoginFormBy = By.id("login2");
    By loginUserNameBy = By.id("loginusername");
    By loginPasswordBy = By.id("loginpassword");
    By loginButtonInLoginFormBy = By.xpath("//*[@id=\"logInModal\"]/div/div/div[3]/button[2]");
    By logoutButtonBy = By.id("logout2");

    public void clickLoginButtonBeforeLoginForm(){
        click(loginButtonBeforeLoginFormBy);
    }

    public void writeUserNameInLoginForm(String userName){
        writeText(loginUserNameBy,userName);
    }

    public void writePasswordInLoginForm(String password){
        writeText(loginPasswordBy,password);
    }
    public void clickLoginButtonInLoginForm(){
        click(loginButtonInLoginFormBy);
    }
    public void clickOnLogoutButton(){click(logoutButtonBy);}
}
