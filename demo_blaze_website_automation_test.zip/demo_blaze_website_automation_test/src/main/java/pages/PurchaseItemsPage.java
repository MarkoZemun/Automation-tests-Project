package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PurchaseItemsPage extends BasePage{
    public PurchaseItemsPage(WebDriver driver) {
        super(driver);
    }


    By samsungGalaxys7AddItemToCartBy = By.xpath("//*[@id=\"tbodyid\"]/div[4]/div/div/h4/a");
    By iphone6AddItemToCartBy = By.xpath("//*[@id=\"tbodyid\"]/div[5]/div/div/h4/a");
    By buttonAddToCartBy = By.xpath("//*[@id=\"tbodyid\"]/div[2]/div/a");
    By productStoreButtonBy = By.id("nava");
    By cartButtonBy = By.id("cartur");
    By placeOrderButtonBy = By.xpath("//*[@id=\"page-wrapper\"]/div/div[2]/button");
    By namePlaceOrderFormBy = By.id("name");
    By countryPlaceOrderFormBy = By.id("country");
    By cityPlaceOrderFormBy = By.id("city");
    By cardPlaceOrderFormBy = By.id("card");
    By monthPlaceOrderFormBy = By.id("month");
    By yearPlaceOrderFormBy = By.id("year");
    By purchaseButtonAfterPlaceOrderFormBy = By.xpath("//*[@id=\"orderModal\"]/div/div/div[3]/button[2]");
    By okButtonBy = By.xpath("/html/body/div[10]/div[7]/div/button");
    By cancelButtonInPlaceOrderFormBy = By.xpath("//*[@id=\"orderModal\"]/div/div/div[3]/button[1]");

    public void clickOnGalaxys7ItemAddToCart(){
        click(samsungGalaxys7AddItemToCartBy);
    }
    public void clikOnButtonAddToCart(){
        click(buttonAddToCartBy);
    }
    public void clikOnProductStoreButton(){
        click(productStoreButtonBy);
    }
    public void clickOnIphone6ItemAddToCart(){
        click(iphone6AddItemToCartBy);
    }
    public void clickOnCartButton(){
        click(cartButtonBy);
    }
    public void clickPlaceOrderButton(){click(placeOrderButtonBy);}


    public void writeNameInPlaceOrderForm(String userName){
            writeText(namePlaceOrderFormBy,userName);
        }
    public void writeCountryInPlaceOrderForm(String country){
        writeText(countryPlaceOrderFormBy,country);
    }
    public void writeCityInPlaceOrderForm(String city){
        writeText(cityPlaceOrderFormBy,city);
    }
    public void writeCardInPlaceOrderForm(String card){
        writeText(cardPlaceOrderFormBy,card);
    }
    public void writeMonthInPlaceOrderForm(String month){
        writeText(monthPlaceOrderFormBy,month);
    }
    public void writeYearInPlaceOrderForm(String year){
        writeText(yearPlaceOrderFormBy,year);
    }
    public void clickOnPurchaseButtonAfterPlaceOrderForm(){
        click(purchaseButtonAfterPlaceOrderFormBy);
    }
    public void clickOnOKButton(){
        click(okButtonBy);
    }
    public void clickOnCancelButtonPlaceOrderForm(){
        click(cancelButtonInPlaceOrderFormBy);
    }






    }

