package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegistrationPage extends BasePage{
    public RegistrationPage(WebDriver driver) {
        super(driver);
    }
    By signInButtonBy = By.id("signin2");
    By userNameFieldBy = By.id("sign-username");
    By passwordFielsBy = By.id("sign-password");
    By clickSignInButtonInSignInForm = By.xpath("//*[@id=\"signInModal\"]/div/div/div[3]/button[2]");

    public void clickOnSignInButton(){
        click(signInButtonBy);
    }
    public void writeUserNameInSignInForm(String userName) {
        writeText(userNameFieldBy,userName);
    }
    public void writePasswordInSignInForm(String password){
        writeText(passwordFielsBy,password);
    }
    public void clickOnSignInButtonInSignInForm(){
        click(clickSignInButtonInSignInForm);
    }


}
