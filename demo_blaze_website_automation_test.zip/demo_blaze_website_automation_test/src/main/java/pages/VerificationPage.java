package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class VerificationPage extends BasePage{
    public VerificationPage(WebDriver driver) {
        super(driver);
    }

    By navaBy = By.id("nava");
    By logoutButton = By.id("logout2");
    By galaxys7MoreInfo = By.id("more-information");
    By galaxys6Info= By.xpath("//*[@id=\"article\"]");
    By loginButtonBy = By.id("login2");


    public VerificationPage verifySignUp(String expectedText){
            String actualText = readText(navaBy);
            Assert.assertEquals(actualText,expectedText);
            return this;
        }

    public VerificationPage verifyLogin(String expectedText){
        String Button = readText(logoutButton);
        Assert.assertEquals(Button,expectedText);
        return this;
    }

    public VerificationPage verifyLogout(String expectedText){
        String login = readText(loginButtonBy);
        Assert.assertEquals(login,expectedText);
        return this;
    }




    public VerificationPage verifyTextPROBA(String expectedText){
        String sony = readText(galaxys6Info);
        Assert.assertEquals(sony,expectedText);
        return this;
    }





    }

