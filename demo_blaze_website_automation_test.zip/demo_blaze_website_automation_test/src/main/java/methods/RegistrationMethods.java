package methods;

import org.openqa.selenium.WebDriver;

import pages.RegistrationPage;



public class RegistrationMethods extends RegistrationPage {
    public RegistrationMethods(WebDriver driver) {
        super(driver);
    }


    public RegistrationPage registration(String username,String password){
        clickOnSignInButton();
        writeUserNameInSignInForm(username);
        writePasswordInSignInForm(password);
        clickOnSignInButtonInSignInForm();

        return this;
    }

}
