package methods;

import org.openqa.selenium.WebDriver;
import pages.PurchaseItemsPage;



public class PurchaseMethods extends PurchaseItemsPage {
    public PurchaseMethods(WebDriver driver) {
        super(driver);
    }


    public PurchaseMethods purchase(String name,String country,String city,String card,String month,String year) {

        try {
            Thread.sleep(700);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        clickOnGalaxys7ItemAddToCart();
        clikOnButtonAddToCart();
        clikOnProductStoreButton();
        clickOnIphone6ItemAddToCart();
        clikOnButtonAddToCart();
        try {
            Thread.sleep(700);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //izbacuje popUp poruku da je item dodat u korpu iako
        // smo mu u BaseTestu rekli da onemoguci notifikacije,pa je dodat kod ispod.
        driver.switchTo().alert().accept();
        clickOnCartButton();
        clickPlaceOrderButton();
        writeNameInPlaceOrderForm(name);
        writeCountryInPlaceOrderForm(country);
        writeCityInPlaceOrderForm(city);
        writeCardInPlaceOrderForm(card);
        writeMonthInPlaceOrderForm(month);
        writeYearInPlaceOrderForm(year);
        clickOnPurchaseButtonAfterPlaceOrderForm();
        clickOnOKButton();
        clickOnCancelButtonPlaceOrderForm();
        return this;
    }
}
