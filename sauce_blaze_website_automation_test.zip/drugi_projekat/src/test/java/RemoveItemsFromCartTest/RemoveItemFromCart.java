package RemoveItemsFromCartTest;

import methods.Remove_Items_From_Cart;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductPage;
import pages.VerificationPage;


public class RemoveItemFromCart extends BaseTestWithPurchasedItems{

    @Test
    public void removeItemFromCart() {
        Remove_Items_From_Cart remove_items_from_cart = new Remove_Items_From_Cart(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        ProductPage productPage = new ProductPage(driver);

        productPage.clickContinueShoppingButton();
        remove_items_from_cart.removeItems();
        try {
            verificationPage.verifyRemove_SauceLabsBackPackFromCart("ADD TO CART");
            System.out.println("Item SAUCE BACKPACK is removed from cart.");

            } catch (Exception e) {
                Assert.fail("Items BACKPACK is not removed from cart");
            }
        try{verificationPage.verifyRemove_SauceLabsBikeLightFromCart("ADD TO CART");
            System.out.println("Items BIKE LIGHT is removed from cart");

        }catch (Exception e){
            Assert.fail("Items is not removed from cart");
        }

    }
}
