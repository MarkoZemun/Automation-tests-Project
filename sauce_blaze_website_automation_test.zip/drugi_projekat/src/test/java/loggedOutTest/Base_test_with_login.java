package loggedOutTest;

import io.github.bonigarcia.wdm.WebDriverManager;
import methods.Login_Methods;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import pages.LoginPage;
import utilities.PropertyManager;

public class Base_test_with_login {

    protected WebDriver driver;

    @BeforeMethod
    public void setup(){

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver(new ChromeOptions().addArguments("--disable-notifications").
                addArguments("--start-maximized"));

        //Bonus
//        WebDriverManager.firefoxdriver().setup();
//
//        driver = new FirefoxDriver(new FirefoxOptions().addArguments("--disable-notifications").
//                addArguments("--start-maximized"));


        LoginPage homePage = new LoginPage(driver);
        Login_Methods loginMethods = new Login_Methods(driver);


        homePage.basePage();
        loginMethods.login(PropertyManager.getInstance().getValid_login_username()
                , PropertyManager.getInstance().getValid_login_password());


    }

    @AfterMethod
    public void teardown(){
        driver.quit();
    }

}
