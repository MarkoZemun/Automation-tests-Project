package loggedOutTest;

import methods.Logout_Methods;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.VerificationPage;

public class Logged_out_test extends Base_test_with_login {


    @Test
    public void Logout() {

        VerificationPage verificationPage = new VerificationPage(driver);
        Logout_Methods logout_methods = new Logout_Methods(driver);


        logout_methods.logout();


        try {
            verificationPage.verifyLogout("Accepted usernames are:\n" +
                    "standard_user\n" +
                    "locked_out_user\n" +
                    "problem_user\n" +
                    "performance_glitch_user");
            System.out.println("User is Logout succesfully!");
        } catch (Exception e) {
            Assert.fail("Functionality is not working properly!");
        }
    }
}