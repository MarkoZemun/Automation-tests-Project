package tests;

import dataCreation.DataCreation;
import methods.Add_To_Cart_Methods;
import methods.CheckOutPageMethods;
import methods.Login_Methods;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class PurchaseItemsTest extends BaseTest {

    @Test
    public void purchaseItemsTest() {
        LoginPage homePage = new LoginPage(driver);
        Add_To_Cart_Methods add_to_cart_methods = new Add_To_Cart_Methods(driver);
        Login_Methods loginMethods = new Login_Methods(driver);
        CheckOutPageMethods checkOutPageMethods = new CheckOutPageMethods(driver);
        DataCreation dataCreation = new DataCreation();
        VerificationPage verificationPage = new VerificationPage(driver);

        homePage.basePage();
        loginMethods.login(PropertyManager.getInstance().getValid_login_username()
                , PropertyManager.getInstance().getValid_login_password());
        add_to_cart_methods.purchase();
        checkOutPageMethods.registration(dataCreation.regData());

        try {
            verificationPage.purchaseItemsVerify("Your order has been dispatched, and will arrive just as fast as the pony can get there!");
            System.out.println("Items successfull ordered");
        } catch (Exception e) {
            Assert.fail("Something went wrong!");
        }
    }
}