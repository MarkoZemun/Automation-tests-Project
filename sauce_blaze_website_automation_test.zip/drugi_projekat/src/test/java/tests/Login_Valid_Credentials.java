package tests;

import methods.Login_Methods;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class Login_Valid_Credentials extends BaseTest {

    @Test
    public void LoginSuccessfull() {
        LoginPage homePage = new LoginPage(driver);
        Login_Methods loginMethods = new Login_Methods(driver);
        VerificationPage verificationPage = new VerificationPage(driver);

        homePage.basePage();
        loginMethods.login(PropertyManager.getInstance().getValid_login_username()
                , PropertyManager.getInstance().getValid_login_password());

        try {
            verificationPage.verifySuccessfullLogin("PRODUCTS");
            System.out.println("User is login successfully");
        } catch (Exception e) {
            Assert.fail("User is not login!");
        }
    }
}