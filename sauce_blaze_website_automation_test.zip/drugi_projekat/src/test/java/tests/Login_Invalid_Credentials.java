package tests;

import methods.Login_Methods;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class Login_Invalid_Credentials extends BaseTest{


    @Test
    public void LoginWithInvalidCredentials() {
        LoginPage homePage = new LoginPage(driver);
        Login_Methods loginMethods = new Login_Methods(driver);
        VerificationPage verificationPage = new VerificationPage(driver);

        homePage.basePage();
        loginMethods.login(PropertyManager.getInstance().getInvalid_login_username()
                , PropertyManager.getInstance().getInvalid_login_password());

        try {
            verificationPage.verifyUnSuccessfullLogin("Epic sadface: Username and password do not match any user in this service");
            System.out.println("Successfully declined user login request");
        } catch (Exception e) {
            Assert.fail("User is logged in ,the functionality is not working properly!");
        }
    }
}
