package tests;

import methods.Login_Methods;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class LoginWithEmptyPasswordField extends BaseTest{

    @Test

    public void LoginEmptyPasswordField(){
        LoginPage homePage = new LoginPage(driver);
        Login_Methods loginMethods = new Login_Methods(driver);
        VerificationPage verificationPage = new VerificationPage(driver);

        homePage.basePage();
        loginMethods.login(PropertyManager.getInstance().getValid_login_username(),"");




        try {
            verificationPage.verifyLoginWithoutPassword("Epic sadface: Password is required");
            System.out.println("Successfully declined user login request");
        }catch (Exception e){
            Assert.fail("User is logged in ,the functionality is not working properly!");
        }
    }
}
