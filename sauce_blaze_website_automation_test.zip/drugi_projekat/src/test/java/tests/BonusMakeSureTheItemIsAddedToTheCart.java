package tests;

import methods.Add_To_Cart_Methods;
import methods.Login_Methods;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class BonusMakeSureTheItemIsAddedToTheCart extends BaseTest{

    @Test

    public void makeSureTheItemsIsAddedToTheCart(){
        Login_Methods loginMethods = new Login_Methods(driver);
        Add_To_Cart_Methods add_to_cart_methods = new Add_To_Cart_Methods(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        LoginPage homePage = new LoginPage(driver);

        homePage.basePage();
        loginMethods.login(PropertyManager.getInstance().getValid_login_username()
                , PropertyManager.getInstance().getValid_login_password());

        add_to_cart_methods.purchase();

        try {verificationPage.rightItemAddedToCart("Sauce Labs Backpack");
            System.out.println("Right item is added to cart list");
        }catch (Exception e){
            Assert.fail("Item is not added to cart list");
        }

    }
}
