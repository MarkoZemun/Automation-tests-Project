package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utilities.PropertyManager;

public class LoginPage extends BasePage{
    public LoginPage(WebDriver driver) {
        super(driver);
    }


    By usernameLoginFieldBy = By.id("user-name");
    By passwordLoginFieldBy = By.id("password");
    By loginButtonBy = By.id("login-button");



public LoginPage basePage(){
driver.get(PropertyManager.getInstance().getUrl());
return this;
}


    public void writeInLoginUserNameFieldBy(String username){
        writeText(usernameLoginFieldBy,username);
    }
    public void writeInLoginPasswordFieldBy(String password){
        writeText(passwordLoginFieldBy,password);
    }
    public void clickOnLoginButtonBy (){
        click(loginButtonBy);
    }

}
