package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage extends BasePage{
    public CheckoutPage(WebDriver driver) {
        super(driver);
    }


    By checkOutButtonBy = By.id("checkout");
    By firstNameFieldRegistrationBy = By.id("first-name");
    By lastNameFieldRegistrationBy = By.id("last-name");
    By zipPostalCodeRegistrationBy = By.id("postal-code");
    By continueButtonAfterRegistrationBy = By.id("continue");
    By finishButtonConfirmOrderBy = By.id("finish");



    public void clickOnCheckoutButton(){
        click(checkOutButtonBy);
    }
    public void writeFirstNameInRegField(String firstName){
        writeText(firstNameFieldRegistrationBy,firstName);
    }
    public void writeLastNameInRegField(String lastName){
        writeText(lastNameFieldRegistrationBy,lastName);
    }
    public void writeZipPostalInRegField(String zipPostal){
        writeText(zipPostalCodeRegistrationBy,zipPostal);
    }
    public void clickOnContinueButtonAfterReg(){
        click(continueButtonAfterRegistrationBy);
}
    public void clickOnfinishButtonAfterReg(){
        click(finishButtonConfirmOrderBy);
    }
    }