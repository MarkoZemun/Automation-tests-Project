package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage extends BasePage {
    public ProductPage(WebDriver driver) {
        super(driver);
    }

    By sauce_Labs_BackpackBy = By.id("add-to-cart-sauce-labs-backpack");
    By SauceLabsBikeLightBy = By.id("add-to-cart-sauce-labs-bike-light");
    By shopping_cart_iconBy = By.className("shopping_cart_link");
    By continueShoppingButtonBy = By.id("continue-shopping");


    public void ClickOnShoppingCartIcon(){click(shopping_cart_iconBy);}
    public void ClickOnSauceLabsBackpackItem(){click(sauce_Labs_BackpackBy);}
    public void ClickOnSauceLabsBikeLight(){click(SauceLabsBikeLightBy);}
    public void clickContinueShoppingButton(){click(continueShoppingButtonBy);}
}
