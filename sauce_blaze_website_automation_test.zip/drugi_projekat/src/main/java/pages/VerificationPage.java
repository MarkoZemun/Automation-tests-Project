package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class VerificationPage extends BasePage{
    public VerificationPage(WebDriver driver) {
        super(driver);
    }


    By errorButtonBy = By.className("login-box");
    By productFromTaskBarBy = By.className("title");
    By verifyLogoutTextBelowLoginFormBy = By.id("login_credentials");
    By checkoutSuccessfullPurchaseTextBy = By.className("complete-text");
    By cartListBy = By.className("inventory_item_name");
    By addToCartButtonSauceLabsBackpackBy = By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]");
    By addToCartButtonSauceLabsBikeLightBy = By.xpath("//*[@id=\"add-to-cart-sauce-labs-bike-light\"]");



    public VerificationPage verifyLoginWithoutUserName(String expectedText){
        String Button = readText(errorButtonBy);
        assertStringEquals(Button, expectedText);
        return this;
    }
    public VerificationPage verifyLoginWithoutPassword(String expectedText){
        String Button = readText(errorButtonBy);
        assertStringEquals(Button, expectedText);
        return this;
    }

    public VerificationPage verifySuccessfullLogin(String expectedText){
        String login = readText(productFromTaskBarBy);
        assertStringEquals(login, expectedText);
        return this;
    }
    public VerificationPage verifyUnSuccessfullLogin(String expectedText){
        String login = readText(errorButtonBy);
        assertStringEquals(login,expectedText);
        return this;
    }
    public VerificationPage verifyLogout(String expectedText){
        String logout = readText(verifyLogoutTextBelowLoginFormBy);
        assertStringEquals(logout,expectedText);
        return this;
    }

    public VerificationPage verifyRemove_SauceLabsBackPackFromCart(String expectedText){
        String addToCart = readText(addToCartButtonSauceLabsBackpackBy);
        assertStringEquals(addToCart,expectedText);
        return this;
    }
    public VerificationPage verifyRemove_SauceLabsBikeLightFromCart(String expectedText){
        String addToCart = readText(addToCartButtonSauceLabsBikeLightBy);
        assertStringEquals(addToCart,expectedText);
        return this;
    }




public VerificationPage purchaseItemsVerify(String expectedText){
        String checkoutComplete = readText(checkoutSuccessfullPurchaseTextBy);
        assertStringEquals(checkoutComplete,expectedText);
        return this;

}


    public VerificationPage rightItemAddedToCart(String expectedText){
        String cartlist = readText(cartListBy);
        assertStringEquals(cartlist,expectedText);
        return this;
    }


}

