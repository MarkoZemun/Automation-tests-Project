package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class YourCartPage extends BasePage{
    public YourCartPage(WebDriver driver) {
        super(driver);
    }


    By removeButtonForSauceLabsBackpackBy = By.id("remove-sauce-labs-backpack");
    By removeButtonForSauceLabsBikeLightBy = By.id("remove-sauce-labs-bike-light");

    public void clickOnRemoveButtonSauceLabsBackPack(){click(removeButtonForSauceLabsBackpackBy);}
    public void clickOnRemoveButtonSauceLabsBikeLight(){click(removeButtonForSauceLabsBikeLightBy);}

}
