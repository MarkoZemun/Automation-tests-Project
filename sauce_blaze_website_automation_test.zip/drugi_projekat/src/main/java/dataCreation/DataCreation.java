package dataCreation;

import com.github.javafaker.Faker;

public class DataCreation {

    public String[] regData() {

        Faker faker = new Faker();

        String firstName = faker.name().firstName();
        String lastName = faker.name().lastName();
        String zipPostal = faker.address().zipCode();

    return new String[]{firstName,lastName,zipPostal};

    }
}
