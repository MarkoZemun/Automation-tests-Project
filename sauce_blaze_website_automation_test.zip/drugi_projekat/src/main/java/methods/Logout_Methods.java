package methods;

import org.openqa.selenium.WebDriver;
import pages.LoggedInPage;

public class Logout_Methods extends LoggedInPage {
    public Logout_Methods(WebDriver driver) {
        super(driver);
    }


    public Logout_Methods logout(){

        clickOdTheBurgerMenu();
        clickOnSidebarLogout();
        return this;
    }
}
