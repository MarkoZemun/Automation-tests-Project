package methods;


import org.openqa.selenium.WebDriver;
import pages.LoginPage;

public class Login_Methods extends LoginPage {
    public Login_Methods(WebDriver driver) {
        super(driver);
    }


    public Login_Methods login(String username, String password){

        writeInLoginUserNameFieldBy(username);
        writeInLoginPasswordFieldBy(password);
        clickOnLoginButtonBy();
        return this;
    }




    //    public Login_Methods loginWithouthUsername(String password){
////        writeInLoginUserNameFieldBy(username);
//        writeInLoginPasswordFieldBy(password);
//        clickOnLoginButtonBy();
//
//        return this;
//    }
//    public Login_Methods loginWitouthPassword(String username){
//       writeInLoginUserNameFieldBy(username);
//      //  writeInLoginPasswordFieldBy(password);
//        clickOnLoginButtonBy();
//
//        return this;
//    }

}
