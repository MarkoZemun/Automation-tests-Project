package methods;

import org.openqa.selenium.WebDriver;
import pages.ProductPage;

public class Add_To_Cart_Methods extends ProductPage {
    public Add_To_Cart_Methods(WebDriver driver) {
        super(driver);
    }


    public Add_To_Cart_Methods purchase(){

        ClickOnSauceLabsBackpackItem();
        ClickOnSauceLabsBikeLight();
        ClickOnShoppingCartIcon();

        return this;
    }
}
