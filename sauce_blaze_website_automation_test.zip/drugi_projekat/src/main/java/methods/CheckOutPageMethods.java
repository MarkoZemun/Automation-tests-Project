package methods;

import org.openqa.selenium.WebDriver;
import pages.CheckoutPage;

public class CheckOutPageMethods extends CheckoutPage {
    public CheckOutPageMethods(WebDriver driver) {
        super(driver);
    }


    public CheckOutPageMethods registration(String[]regData){

        clickOnCheckoutButton();
        writeFirstNameInRegField(regData[0]);
        writeLastNameInRegField(regData[1]);
        writeZipPostalInRegField(regData[2]);
        clickOnContinueButtonAfterReg();
        clickOnfinishButtonAfterReg();
        return this;
    }
}
