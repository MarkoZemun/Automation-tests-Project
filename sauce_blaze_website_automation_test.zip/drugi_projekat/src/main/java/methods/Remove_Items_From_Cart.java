package methods;

import org.openqa.selenium.WebDriver;
import pages.YourCartPage;

public class Remove_Items_From_Cart extends YourCartPage {
    public Remove_Items_From_Cart(WebDriver driver) {
        super(driver);
    }


    public Remove_Items_From_Cart removeItems(){
        clickOnRemoveButtonSauceLabsBackPack();
        clickOnRemoveButtonSauceLabsBikeLight();
        return this;
    }

}
