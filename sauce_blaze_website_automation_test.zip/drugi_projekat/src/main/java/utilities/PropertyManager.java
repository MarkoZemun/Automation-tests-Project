package utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyManager {

    private static String url;
    private static String valid_login_username;
    private static String invalid_login_username;
    private static String valid_login_password;
    private static String invalid_login_password;




        public static PropertyManager getInstance(){
            Properties properties = new Properties();
            PropertyManager propertyManager = new PropertyManager();

            try {
                FileInputStream fileInput = new FileInputStream("src/main/resources/configuration.properties");
                properties.load(fileInput);
            } catch (Exception e) {
                e.printStackTrace();
            }
            url = properties.getProperty("url");
            valid_login_username = properties.getProperty("valid_login_username");
            invalid_login_username = properties.getProperty("invalid_login_username");
            valid_login_password = properties.getProperty("valid_login_password");
            invalid_login_password = properties.getProperty("invalid_login_password");
            return propertyManager;

        }
        public String getUrl(){
            return url;
        }

        public  String getValid_login_username() {
            return valid_login_username;
        }

        public  String getInvalid_login_username() {
            return invalid_login_username;
        }

        public  String getValid_login_password() {
            return valid_login_password;
        }

        public  String getInvalid_login_password() {
            return invalid_login_password;
        }


    }
